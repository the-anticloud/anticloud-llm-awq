# OSINT Benchmark — LLM_AWQ

**Upstream:** https://github.com/mit-han-lab/llm-awq

Public-record information collected about upstream project:

- GitHub stars: see upstream
- License: MIT
- Last commit: check upstream
- Known CVEs: check NVD

Status: PENDING systematic collection.
